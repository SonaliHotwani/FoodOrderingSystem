package food.ordering.system.exception;

public class RestaurantNotFoundException extends RuntimeException{
}
