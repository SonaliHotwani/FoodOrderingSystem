package food.ordering.system.model;

public enum Status {
    COMPLETED,
    ACCEPTED
}
