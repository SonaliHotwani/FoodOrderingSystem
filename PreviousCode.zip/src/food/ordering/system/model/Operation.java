package food.ordering.system.model;

public enum Operation {
    ADD_NEW,
    UPDATE_EXISTING
}
