package food.ordering.system.service;

import food.ordering.system.model.Order;
import food.ordering.system.model.PlaceOrderRequest;
import food.ordering.system.model.Restaurant;

import java.util.List;
import java.util.Set;

public class OrderService {
    List<Order> orders;

    public Order assignRestaurant(PlaceOrderRequest placeOrderRequest, Set<Restaurant> restaurants) {
        final String restaurantName = placeOrderRequest.getStrategy().assignRestaurant(placeOrderRequest.getItems(), restaurants);
        int orderId = orders.size() +1;
        final Order order = new Order(restaurantName, orderId);
        orders.add(order);
        return order;
    }
}
